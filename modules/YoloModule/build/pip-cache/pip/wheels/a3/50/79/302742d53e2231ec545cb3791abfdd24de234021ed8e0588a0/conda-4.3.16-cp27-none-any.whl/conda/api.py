from .core.index import get_index
get_index_ = get_index
